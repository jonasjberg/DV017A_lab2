package test;

public class Constants
{
    public static final double PRECISION = 0.001;
    public static final double DELTA     = 1e-15;
}
